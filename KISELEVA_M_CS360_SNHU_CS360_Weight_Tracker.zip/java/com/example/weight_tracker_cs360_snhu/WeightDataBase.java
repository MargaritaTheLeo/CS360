package com.example.weight_tracker_cs360_snhu;

// Importing all the necessary libraries and widgets
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.content.Context;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;

// Defining a public class for the WeightDataBase
public class WeightDataBase extends SQLiteOpenHelper {

    // Declaring the variables
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "weights.db";
    private static WeightDataBase weightDB;

    // Creating a private constructor since it will be use only once
    private WeightDataBase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Defining a public method for accessing the weights database
    public static WeightDataBase getInstance(Context context) {
        if (weightDB == null) {
            weightDB = new WeightDataBase(context);
        }
        return weightDB;
    }

    // Defining a method for creating a weight diary of the user
    @Override
    public void onCreate(SQLiteDatabase dataBase) {
        dataBase.execSQL("create Table weights(_ID INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, date text, weight float)");

        // Setting up user's goal
        dataBase.execSQL("create Table goals(username TEXT primary key, goal float)");
    }

    // Updating the diary with
    @Override
    public void onUpgrade(SQLiteDatabase dataBase, int oldVersion, int newVersion) {
        dataBase.execSQL("drop Table if exists weights");
        dataBase.execSQL("drop Table if exists goals");
    }

    // Creating a method for adding weight entries
    public Boolean addEntry(WeightClass _entry, UserClass _user){
        SQLiteDatabase dataBase = this.getWritableDatabase();
        ContentValues values= new ContentValues();
        values.put("username", _user.getUserName());
        values.put("date", _entry.getDate());
        values.put("weight", _entry.getWeight());
        long id = dataBase.insert("weights", null, values);
        return id != -1;
    }

    // Creating a method for removing weight entries
    public void removeEntry(Integer entryID){
        SQLiteDatabase dataBase = this.getWritableDatabase();
        dataBase.delete("weights","_id = ?",new String[]{String.valueOf(entryID)});
    }

    // Creating a method for updating weight entries
    public Boolean updateEntry(int _id, float weight, UserClass _user){
        SQLiteDatabase dataBase = this.getWritableDatabase();
        ContentValues values= new ContentValues();
        values.put("username", _user.getUserName());
        values.put("weight", weight);
        long id = dataBase.update("weights", values, "_id = " + _id, null);
        return id != -1;
    }

    // Creating a method for adding user's weight goal
    public void addGoal(UserClass _user){
        SQLiteDatabase dataBase = this.getWritableDatabase();
        ContentValues values= new ContentValues();
        values.put("username", _user.getUserName());
        values.put("goal", _user.getGoal());

        // Checking for an existing goal
        Boolean goalSet = false;
        long id = 0;
        String Query = "Select * from goals";
        Cursor cursor = dataBase.rawQuery(Query, null);

        // Getting the user from the database
        if(cursor.moveToFirst()){
            do {
                String username = cursor.getString(0);
                if(username.equals(_user.getUserName())){
                    goalSet = true;
                    break;
                }
            } while (cursor.moveToNext());
        }

        // If the goal has NOT been set yet
        if(!goalSet){
            id = dataBase.insert("goals", null, values);
        }
        // If the goal is set
        else{
            id = dataBase.updateWithOnConflict("goals", values, "username = ?",
                    new String[] {_user.getUserName()}, SQLiteDatabase.CONFLICT_REPLACE );
        }
    }

    // Creating a method for accessing user's goal
    public float getGoal(UserClass _user){
        SQLiteDatabase dataBase = this.getWritableDatabase();
        ContentValues values= new ContentValues();

        // Checking if the goal is set
        float goalSet = 0;
        String Query = "Select * from goals";
        Cursor cursor = dataBase.rawQuery(Query, null);

        // Getting the user from the database
        if(cursor.moveToFirst()){
            do {
                String username = cursor.getString(0);
                if(username.equals(_user.getUserName())){
                    goalSet = cursor.getFloat(1);
                    break;
                }
            } while (cursor.moveToNext());
        }
        return (goalSet != 0) ? goalSet : 0;
    }

    // Defining a method for accessing all the weights from the database
    public List<WeightClass> getAllWeights(UserClass user) throws ParseException {
        List<WeightClass> allEntry = new ArrayList<>();
        SQLiteDatabase dataBase = this.getWritableDatabase();
        Cursor cursor = dataBase.rawQuery("SELECT * FROM weights ORDER BY date", null);

        // Getting the username from the database
        if(cursor.moveToFirst()){
            do {
                String username = cursor.getString(1);

                // Checking for a matching username in logged in status
                // If the name matches, starting the loop
                if (username.equals(user.getUserName())){
                    int ID = cursor.getInt(0);
                    String date = cursor.getString(2);

                    // Setting the date format to "MM-DD-YYYYY"
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd");
                    Date newDate = null;
                    String prettyDate = null;
                    try {
                        newDate = format.parse(date);
                        format = new SimpleDateFormat("mm-dd-yyy");
                        prettyDate = format.format(newDate);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    // Using the constructor to create objects, then adding those to the list
                    int userWeight = cursor.getInt(3);
                    WeightClass newEntry = new WeightClass(ID, prettyDate, userWeight);
                    allEntry.add(newEntry);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return allEntry;
    }

    // Creating a method for deleting the user
    public void deleteUser(UserClass _user){
        SQLiteDatabase _db = this.getWritableDatabase();
        _db.delete("goals", "username = ?", new String[]{_user.getUserName()} );
        _db.delete("weights", "username = ?", new String[]{_user.getUserName()} );
    }

}

