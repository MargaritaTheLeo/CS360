package com.example.weight_tracker_cs360_snhu;

// TODO!
// For the final project need to create a method for deleting a user from the database
// Also need to add day/night mode functionality

// Importing all the necessary libraries and widgets
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

// Defining a public class for the UserSettings
public class Settings extends AppCompatActivity {

    // Declaring the variables
    UserDataBase userDB;
    WeightDataBase weights;
    UserClass userClass;
    EditText phone;
    Button deleteAccount;
    CompoundButton switchButton;

    // Creating a protected method for the user's settings functioning
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Defining the method's variables
        userClass = UserClass.getUserInstance();
        phone = findViewById(R.id.editTextPhone);
        phone.setText(userClass.getSMSText());
        switchButton = findViewById(R.id.notifications);
        switchButton.setChecked(userClass.isTextPermission());
        switchButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            // Setting up text permissions
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                userClass.setTextPermission(isChecked);
            }
        });

    }

    // Setting up method for sending SMS notifications
    public void openMain(View view) {
        phone = findViewById(R.id.editTextPhone);
        String sPhone = phone.getText().toString();
        // If the phone number is provided, send the SMS
        if(sPhone != null){
            userClass.setSMSText(sPhone);
        }
        Intent intent = new Intent(this, HomeScreen.class);
        startActivity(intent);
    }

    // Defining a method for deleting user account
    public void deleteUserAccounts(View view){
        // Accessing the databases
        userDB = UserDataBase.getInstance(this);
        weights = WeightDataBase.getInstance(this);
        userClass = UserClass.getUserInstance();

        // Deleting the user from both databases
        weights.deleteUser(userClass);
        userDB.deleteUser(userClass);

        // Logging the user out
        this.finishAffinity();
        System.exit(0);
    }

}
