package com.example.weight_tracker_cs360_snhu;

// Importing all the necessary libraries and widgets
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.DialogInterface;
import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;

// Defining a public class for the MainActivity
public class LoginRegistration extends AppCompatActivity {

    // Declaring the variables
    private DialogInterface.OnClickListener dialogClickListener;
    EditText username;
    EditText password;
    UserDataBase userDB;
    WeightDataBase weights;
    UserClass validUser;
    Button loginBTN;
    TextView passwordMSG;

    // Defining a method that allows for the user's login
    private void loginSuccess(View view, String _user) {

        // Initiating the database containing weights
        weights = WeightDataBase.getInstance(this);

        // Instantiating the UserClass object
        validUser = UserClass.getUserInstance();
        validUser.setUserName(_user);
        validUser.setGoal(weights.getGoal(validUser));

        // Starting a new activity
        Intent intent = new Intent(this, HomeScreen.class);
        startActivity(intent);
    }

    // Starting the activity lifecycle
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_registration);
        username = findViewById(R.id.textUsername);
        password = findViewById(R.id.textPassword);
        loginBTN = findViewById(R.id.buttonLogin);
        passwordMSG = findViewById(R.id.passwordMessage);

        // Call the user database singleton
        userDB = UserDataBase.getInstance(this);

        // Getting the username and password of the user
        loginBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String _username = username.getText().toString();
                String _password = password.getText().toString();

                // Setting up booleans for validating user's credentials
                boolean validUser = userDB.checkUserName(_username);
                boolean validPass = userDB.checkUserPassword(_username, _password);

                // Evaluating user's credentials
                // If the user is authorized
                if(validUser) {
                    if(validPass) {
                        Toast.makeText(LoginRegistration.this,"Login Success",Toast.LENGTH_SHORT).show();
                        loginSuccess(v, _username);
                    }
                    // If the password does not match the database
                    else {
                        Toast.makeText(LoginRegistration.this,"Incorrect Password!!!",Toast.LENGTH_SHORT).show();
                    }
                }
                // If the user is not recognized
                else if(!validUser) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(LoginRegistration.this);
                    builder
                            // Setting up registration mechanism
                            .setTitle("Account is not recognized!")
                            .setMessage("Would you like to register?")
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    // If the user wants to register, insert user into the database
                                    Boolean userAdded = userDB.insertUser(_username, _password);
                                    // If the user is added successfully
                                    if(userAdded){
                                        Toast.makeText(LoginRegistration.this,"Account added",Toast.LENGTH_SHORT).show();
                                    }
                                    // If failed
                                    else{
                                        Toast.makeText(LoginRegistration.this,"Failed to add account",Toast.LENGTH_SHORT).show();
                                    }
                                }
                            })
                            // If the user does not want to register
                            .setNegativeButton("No", null)
                            .show();
                }
            }
        });

        // Setting up mechanism for inserting password
        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            // Monitoring the validity of the password while hiding it from the view
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // If the password is longer than five characters
                if (s.length() < 5) {
                    // Enabling the login button
                    passwordMSG.setVisibility(View.VISIBLE);
                } else {
                    // Disabling the login button
                    passwordMSG.setVisibility(View.INVISIBLE);
                    loginBTN.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

}