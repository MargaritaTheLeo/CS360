package com.example.weight_tracker_cs360_snhu;

// Defining a public class WeightsClass
public class WeightClass {

    // Defining the variables
    private int ID;
    private String date;
    private float weight;

    // Instantiating a weight class with ID
    public WeightClass(int ID, String date, float weight) {
        this.ID = ID;
        this.date = date;
        this.weight = weight;
    }

    // Instantiating a weight class with no ID
    public WeightClass(String date, float weight) {
        this.date = date;
        this.weight = weight;
    }

    // Defining the class' methods
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public float getWeight() {
        return weight;
    }
    public void setWeight(float weight) {
        this.weight = weight;
    }
    public int getID() {return ID;}
    public void setID(int ID) {this.ID = ID;

    }
}

