package com.example.weight_tracker_cs360_snhu;

// Importing all the necessary libraries and widgets
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.content.DialogInterface;
import android.content.Intent;
import java.util.ArrayList;
import java.util.List;
import java.text.ParseException;
import android.text.InputType;
import android.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

// Defining a public class for the MainScreen
public class HomeScreen extends AppCompatActivity {

    // Declaring the variables
    WeightDataBase weight;
    UserClass myUser;

    // Defining a method that allows user to edit weight
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        Button editBtn = findViewById(R.id.buttonEditWeight);

        // Taking care of exceptions
        try {
            onInit();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    // Defining a method that creates menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    // Defining a method that allows user click on menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        openSettings();
        return false;
    }

    // Defining a method that enables user's settings
    public void openSettings(){
        Intent intent = new Intent(this, Settings.class);
        startActivity(intent);
    }

    // Defining a method that enables edit button
    public void openEdit(View view){
        Intent intent = new Intent(this, WeightEditing.class);
        startActivity(intent);
    }

    // Defining a method that enables entering weight
    public void openWeightForm(View view){
        Intent intent = new Intent(this, WeightAdding.class);
        startActivity(intent);
    }

    // Defining a method that handles storage of user's data including weight goal
    public void onNewGoal(View view){

        // Calling the databases
        UserClass _user = UserClass.getUserInstance();
        WeightDataBase weightDB = WeightDataBase.getInstance(this);

        // Searching for the user and their weight in the databases
        AlertDialog.Builder builder = new AlertDialog.Builder(HomeScreen.this);
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_NUMBER);

        // Creating an interface responsible for changing user's weight goal
        builder
                .setView(input)
                .setTitle("Enter your new weight goal below.")
                // Prompting the user to confirm the goal change
                .setMessage("Your current goal is " + _user.getGoal() + " lbs.")
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    // Setting the new goal
                    public void onClick(DialogInterface dialog, int which) {
                        float userGoal = Float.valueOf(input.getText().toString());
                        myUser.setGoal(userGoal);
                        weightDB.addGoal(myUser);
                        myUser.setGoal(userGoal);
                        finish();
                        overridePendingTransition(0, 0);
                        startActivity(getIntent());
                        overridePendingTransition(0, 0);
                    }
                })
                // Allowing the user to decline the change
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Defining a method for adding the new weight to the table
    private void onInit() throws ParseException {
        weight = WeightDataBase.getInstance(this);
        myUser = UserClass.getUserInstance();
        List<WeightClass> allEntry = new ArrayList<>();
        allEntry = weight.getAllWeights(myUser);

        // Adding the table rows
        TableLayout table = findViewById(R.id.weight_table);

        // Defining the table's headers
        TableRow header = new TableRow(this);

        // Header #1
        TextView headerColumn1 = new TextView(this);
        headerColumn1.setText("Date");
        headerColumn1.setBackgroundResource(R.color.pale_yellow);
        headerColumn1.setGravity(Gravity.CENTER);
        headerColumn1.setPadding(5,10,5,10);
        header.addView(headerColumn1);

        // Header #2
        TextView headerColumn2 = new TextView(this);
        headerColumn2.setText("Weight");
        headerColumn2.setBackgroundResource(R.color.pale_yellow);
        headerColumn2.setGravity(Gravity.CENTER);
        headerColumn2.setPadding(5,10,5,10);
        header.addView(headerColumn2);

        // Header #3
        TextView headerColumn3 = new TextView(this);
        headerColumn3.setText("Remaining Weight");
        headerColumn3.setBackgroundResource(R.color.pale_yellow);
        headerColumn3.setGravity(Gravity.CENTER);
        headerColumn3.setPadding(5,10,5,10);
        header.addView(headerColumn3);

        // Adding the headers
        table.addView(header);

        // A loop for filling the table with data
        for (int i = 0; i < allEntry.size(); i++){
            TableRow row = new TableRow(this);
            TextView textColumn1 = new TextView(this);

            // Text #1
            textColumn1.setText(allEntry.get(i).getDate());
            textColumn1.setTextSize(16);
            textColumn1.setBackgroundResource(R.color.white);
            textColumn1.setGravity(Gravity.CENTER_HORIZONTAL);
            textColumn1.setPadding(5,10,5,10);
            row.addView(textColumn1);

            // Text #2
            TextView textColumn2 = new TextView(this);
            textColumn2.setText(String.valueOf(allEntry.get(i).getWeight()));
            textColumn2.setTextSize(16);
            textColumn2.setBackgroundResource(R.color.white);
            textColumn2.setGravity(Gravity.CENTER_HORIZONTAL);
            textColumn2.setPadding(5,10,5,10);
            row.addView(textColumn2);

            // Text #3
            TextView textColumn3 = new TextView(this);
            float weightRemain = allEntry.get(i).getWeight() - myUser.getGoal();
            String stringWeightRemain = String.valueOf(weightRemain);
            textColumn3.setText(stringWeightRemain);
            textColumn3.setTextSize(16);
            textColumn3.setBackgroundResource(R.color.white);
            textColumn3.setGravity(Gravity.CENTER_HORIZONTAL);
            textColumn3.setPadding(5,10,5,10);
            row.addView(textColumn3);

            // Finalizing the table view
            table.addView(row);
        }
    }
}
