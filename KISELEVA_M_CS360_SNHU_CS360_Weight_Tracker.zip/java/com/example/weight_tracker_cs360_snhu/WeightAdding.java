package com.example.weight_tracker_cs360_snhu;

// Importing all the necessary libraries and widgets
import androidx.appcompat.app.AppCompatActivity;
import android.widget.DatePicker;
import android.widget.EditText;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import java.util.Calendar;

// Defining a public class WeightEntry
public class WeightAdding extends AppCompatActivity {

    // Declaring variables
    protected EditText dateEntry;
    protected EditText weightEntry;
    protected String isoDate;
    UserClass userClass;
    WeightDataBase weightDB;

    // Creating a method for entering weight
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_adding);
        dateEntry = findViewById(R.id.editWeightDate);
        weightEntry = findViewById(R.id.editWeightWeight);
        userClass = UserClass.getUserInstance();
        weightDB = WeightDataBase.getInstance(this);

        // Setting up a calendar instance
        dateEntry.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                // creating a variable for a date picker dialog
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        // Passing the context
                        WeightAdding.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                // Setting date to the text box
                                dateEntry.setText((monthOfYear + 1) + "-" + dayOfMonth  + "-" + year);
                                isoDate = String.valueOf(year) + "-" + String.valueOf(monthOfYear + 1) + "-" +
                                        String.valueOf(dayOfMonth);
                            }
                        },
                        // Passing year, month, and day
                        year, month, day);
                // Displaying the date picker dialog
                datePickerDialog.show();
            }
        });
    }

    // Defining a method for displaying the main form
    public void openMainForm(View view){
        Intent intent = new Intent(this, HomeScreen.class);
        startActivity(intent);
    }

    // Defining a method for saving data
    public void onSaveClick(View view){
        String date = dateEntry.getText().toString();
        String sWeight = weightEntry.getText().toString();
        float weight = 0;

        // Protecting the system from an empty form
        if (!date.equals("") && !sWeight.equals("")){
            weight = Float.valueOf(sWeight);
            WeightClass entry = new WeightClass(isoDate, weight);
            Boolean weightAdd = weightDB.addEntry(entry, userClass);

            // Checking if the user reach the goal
            // If the goal is reached, checking if the notifications are allowed
            // If yes, sending an SMS
            if(weight <= userClass.getGoal()){
                if(userClass.isTextPermission()){
                    Notifications.sendLongSMS(userClass.getSMSText());
                }
            }
        }

        // Back tot he main screen
        Intent intent = new Intent(this, HomeScreen.class);
        startActivity(intent);
    }
}
