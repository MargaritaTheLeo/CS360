package com.example.weight_tracker_cs360_snhu;

// Importing all the necessary libraries and widgets
import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.Gravity;
import android.view.View;
import android.text.InputType;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import android.os.Bundle;

// Defining a public class for the ViewEdit
public class WeightEditing extends AppCompatActivity {

    // Declaring the variables
    WeightDataBase weightDB;
    UserClass userClass;

    // Creating a list for IDs of checked boxes
    List<CompoundButton> checkedRows = new ArrayList<>();

    // Defining a method for creating the content view
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_editing);

        // Catching exceptions
        try {
            onInit();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
    // Defining a method for opening a form for weight editing
    public void openWeightForm(View view){
        Intent intent = new Intent(this, WeightAdding.class);
        startActivity(intent);
    }

    // Defining a method for starting the main screen activity
    public void openMain(View view){
        Intent intent = new Intent(this, HomeScreen.class);
        startActivity(intent);
    }

    // Defining a method for displaying the table
    public void onInit() throws ParseException {
        weightDB = WeightDataBase.getInstance(this);
        userClass = UserClass.getUserInstance();
        List<WeightClass> allEntry = new ArrayList<>();
        allEntry = weightDB.getAllWeights(userClass);

        // Adding new rows to the table
        TableLayout table = findViewById(R.id.editTable);

        // Adding headers
        TableRow header = new TableRow(this);

        // Header #1
        TextView headerColumn1 = new TextView(this);
        headerColumn1.setText("Selection");
        headerColumn1.setBackgroundResource(R.color.pale_yellow);
        headerColumn1.setGravity(Gravity.CENTER);
        headerColumn1.setPadding(10,10,10,10);
        header.addView(headerColumn1);

        // Header #2
        TextView headerColumn2 = new TextView(this);
        headerColumn2.setText("Date");
        headerColumn2.setBackgroundResource(R.color.pale_yellow);
        headerColumn2.setGravity(Gravity.CENTER);
        headerColumn2.setPadding(10,10,10,10);
        header.addView(headerColumn2);

        // Header #3
        TextView headerColumn3 = new TextView(this);
        headerColumn3.setText("Weight");
        headerColumn3.setBackgroundResource(R.color.pale_yellow);
        headerColumn3.setGravity(Gravity.CENTER);
        headerColumn3.setPadding(10,10,10,10);
        header.addView(headerColumn3);

        // Adding the headers
        table.addView(header);

        // A loop for populating the table with data
        for (int i = 0; i < allEntry.size(); i++){
            TableRow row = new TableRow(this);
            CheckBox check = new CheckBox(this);
            check.setGravity(Gravity.CENTER);
            check.setPadding(5,10,5,10);
            check.setId(allEntry.get(i).getID());
            TableRow.LayoutParams rowParams = new TableRow.LayoutParams();
            rowParams.gravity = Gravity.CENTER;
            rowParams.span = 1;
            check.setLayoutParams(rowParams);
            check.setOnClickListener(new View.OnClickListener(){

                // Defining actions upon clicking
                @Override
                public void onClick(View v) {
                    int ID = ((CompoundButton) v).getId();
                    String sID = String.valueOf(ID);

                    // If checked, add the box to the collection
                    if(((CompoundButton) v).isChecked()) {
                        checkedRows.add((CompoundButton) v);
                    }
                    // If NOT checked, remove the box from the collection
                    else {
                        checkedRows.remove((CompoundButton) v);
                    }
                }
            });

            // Adding the rows
            row.addView(check);

            // Text #1
            TextView textColumn1 = new TextView(this);
            textColumn1.setText(allEntry.get(i).getDate());
            textColumn1.setTextSize(16);
            textColumn1.setBackgroundResource(R.color.white);
            textColumn1.setGravity(Gravity.CENTER_HORIZONTAL);
            textColumn1.setPadding(5,10,5,10);
            row.addView(textColumn1);

            // Text #2
            TextView textColunm2 = new TextView(this);
            textColunm2.setText(String.valueOf(allEntry.get(i).getWeight()));
            textColunm2.setTextSize(16);
            textColunm2.setBackgroundResource(R.color.white);
            textColunm2.setGravity(Gravity.CENTER_HORIZONTAL);
            textColunm2.setPadding(5,10,5,10);
            row.addView(textColunm2);

            table.addView(row);
        }
    }

    // Defining a method for deleting the rows
    public void delRow(View view){

        // A loop for removing the rows from the collection
        for(CompoundButton a : checkedRows){
            weightDB.removeEntry(a.getId());
        }

        // Refreshing the screen
        finish();
        overridePendingTransition(0, 0);
        startActivity(getIntent());
        overridePendingTransition(0, 0);
    }

    // Defining a method for editing rows
    public void editRow(View view){

        for (CompoundButton a : checkedRows) {
            AlertDialog.Builder builder = new AlertDialog.Builder(WeightEditing.this);
            final EditText input = new EditText(this);
            input.setInputType(InputType.TYPE_CLASS_TEXT| InputType.TYPE_CLASS_NUMBER);

            // Setting up prompts for the user
            builder
                    .setView(input)
                    .setTitle("Edit the record")
                    .setMessage("What is the new weight?")
                    .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            float newWeight = Float.valueOf(input.getText().toString());
                            weightDB.updateEntry(a.getId(), newWeight, userClass);
                            finish();
                            overridePendingTransition(0, 0);
                            startActivity(getIntent());
                            overridePendingTransition(0, 0);
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        }
    }
}
