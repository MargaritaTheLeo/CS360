package com.example.weight_tracker_cs360_snhu;

// Importing all the necessary libraries
import android.telephony.SmsManager;
import java.util.ArrayList;

// Defining a public class for the SMSNotifications
public class Notifications {

    // Defining a method for notifying the user of the reached goal
    public static void sendLongSMS(String phoneNumber) {
        // Message contents
        String message = "Goal Reached! Congratulations!";
        SmsManager smsManager = SmsManager.getDefault();
        ArrayList<String> parts = smsManager.divideMessage(message);
        // Allowing the message to be sent
        smsManager.sendMultipartTextMessage(phoneNumber, null, parts, null, null);
    }

}

