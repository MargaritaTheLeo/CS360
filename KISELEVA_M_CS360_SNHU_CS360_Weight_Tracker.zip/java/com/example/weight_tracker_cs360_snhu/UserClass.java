package com.example.weight_tracker_cs360_snhu;

// NOTE!
// A user class has been created
// Username: User1
// Password: password1

// Defining a public class UserModel that handles a valid registered user
public class UserClass {

    // Declaring the variables
    private String userName;
    private String SMSText = "0123456789";
    private static UserClass loggedUser;
    private float goal = 0; //default to zero
    private boolean textPermission = false;

    // Defining a method that allows only one user to be logged in at a time
    public static UserClass getUserInstance(){
        if(loggedUser == null){
            loggedUser = new UserClass();
        }
        return loggedUser;
    }

    // Making a private UserClass constructor
    private UserClass(){}

    // Declaring the variables
    public String getUserName() {
        return userName;
    }
    public String getSMSText() {
        return SMSText;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public void setGoal(float goal) {
        this.goal = goal;
    }
    public void setTextPermission(boolean textPermission) {
        this.textPermission = textPermission;
    }
    public void setSMSText(String SMSText) {
        this.SMSText = SMSText;
    }
    public boolean isTextPermission() {return textPermission;}
    public float getGoal() {
        return goal;
    }
}


