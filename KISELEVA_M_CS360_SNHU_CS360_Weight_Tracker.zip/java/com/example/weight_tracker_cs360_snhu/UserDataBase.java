package com.example.weight_tracker_cs360_snhu;

// NOTE!
// A user has been added to the database
// Username: User1
// Password: password1

// Importing all the necessary libraries and widgets
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.content.Context;

// Defining a public class for the UserDataBase
public class UserDataBase extends SQLiteOpenHelper {

    // Declaring the variables
    private static UserDataBase userDB;
    private static final int VERSION = 1;
    private static final String DATABASE = "users.db";

    // Creating a private constructor for UserDataBase intended to be a singleton
    private UserDataBase(Context context){
        super(context, DATABASE, null, VERSION);
    }

    // Defining a method for accessing the database
    public static UserDataBase getInstance(Context context) {
        if (userDB == null) {
            userDB = new UserDataBase(context);
        }
        return userDB;
    }

    // Creating the database table
    @Override
    public void onCreate(SQLiteDatabase dataBase) {
        dataBase.execSQL("create Table users(username TEXT primary key, password TEXT)");
    }

    // Making sure there are no duplicates
    @Override
    public void onUpgrade(SQLiteDatabase dataBase, int oldVersion, int newVersion) {
        dataBase.execSQL("drop Table if exists users");
    }

    // Creating a mechanism for adding new users
    public Boolean insertUser(String userName, String password) {
        SQLiteDatabase dataBase = this.getWritableDatabase();
        ContentValues values= new ContentValues();
        values.put("username", userName);
        values.put("password", password);
        long writeResult = dataBase.insert("users", null, values);

        // Confirming the successful addition
        return writeResult != -1;
    }

    // Creating a method that checks user's name
    public Boolean checkUserName(String userName) {
        SQLiteDatabase dataBase = this.getWritableDatabase();
        Cursor cursor = dataBase.rawQuery("Select * from users where username = ?",
                new String[]{userName});
        return cursor.getCount() > 0;
    }

    // If the username is not in the database, creating a new user with a password

    // Creating a method that checks user's password
    public Boolean checkUserPassword(String userName, String password) {
        SQLiteDatabase dataBase = this.getWritableDatabase();
        Cursor cursor = dataBase.rawQuery("Select * from users where username = ? and password =?",
                new String[]{userName, password});
        return cursor.getCount() > 0;
    }

    // Deleting a user from the database
    public void deleteUser(UserClass _user) {
        SQLiteDatabase dataBase = this.getWritableDatabase();
        dataBase.delete("users", "username = ?", new String[]{_user.getUserName()} );
    }

}



